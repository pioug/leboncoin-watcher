Polaris UI and Linecons

Polaris UI and Linecons was specially made for Smashing Magazine by our friends Designmodo.com. 

Thanks for supporting our website and enjoy!

Updates:
http://designmodo.com/polaris-free
http://designmodo.com/linecons-free

